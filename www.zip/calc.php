<?php $i = 10; ?>
<?php while ($i <= 100): ?>

<option value="<?php echo $i ?>"><?php echo $i ?></option>

<?php $i++; ?>
<?php endwhile; ?>